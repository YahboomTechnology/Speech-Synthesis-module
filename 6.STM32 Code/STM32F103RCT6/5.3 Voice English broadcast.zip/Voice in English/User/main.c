#include "stm32f10x.h"
#include "bsp_i2c.h"
#include "bsp_usart1.h"

int main(void)
{
	u8 result = 0xff;
	//I2C��ʼ��
	I2C_Bus_Init();
	NVIC_Configuration();
	USARTx_Config();
	
	
	SetArticulation(Articulation_Word);//����Ӣ�ĵ��ʷ���
	
	SetVolume(10);
	SetReader(Reader_XiaoPing);
	speech_text("hello yahboom intelligent Technology",GB2312);
	while(GetChipStatus() != ChipStatus_Idle)
	{
	  delay(50);
	}


	SetReader(Reader_XuDuo);
	speech_text("Welcome to use yahboom intelligent technology voice broadcast module",GB2312);
	while(GetChipStatus() != ChipStatus_Idle)
	{
	  delay(50);
	}
	

	
	while(1)
	{
		
	}
				
}

/*********************************************END OF FILE**********************/
