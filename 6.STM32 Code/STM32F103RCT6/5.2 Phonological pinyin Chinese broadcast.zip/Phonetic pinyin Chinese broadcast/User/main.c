#include "stm32f10x.h"
#include "bsp_i2c.h"
#include "bsp_usart1.h"

int main(void)
{
	u8 result = 0xff;
	//I2C��ʼ��
	I2C_Bus_Init();
	NVIC_Configuration();
	USARTx_Config();
	
	
	SetSpell(Spell_Enable);
	SetVolume(10);
	SetReader(Reader_XiaoPing);
	speech_text("ni2hao3ya4bo2zhi4neng2ke1ji4",GB2312);
	while(GetChipStatus() != ChipStatus_Idle)
	{
	  delay(50);
	}


	SetReader(Reader_XuDuo);
	speech_text("huan1yin2shi3yong4ya4bo2zhi4neng2yu3yin1bo1bao4mo2kuai4",GB2312);
	while(GetChipStatus() != ChipStatus_Idle)
	{
	  delay(50);
	}
	

	
	while(1)
	{
		
	}
				
}

/*********************************************END OF FILE**********************/
